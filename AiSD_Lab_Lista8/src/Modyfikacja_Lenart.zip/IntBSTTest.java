import java.util.Comparator;

public class IntBSTTest<Integer> extends BinarySearchTree<Integer> {
    private int max;
    public IntBSTTest(Comparator<Integer> comparator) {
        super(comparator);
        this.max = 0;
    }
    public IntBSTTest(Comparator<Integer> comparator, Node<Integer> newRoot){
        super(comparator);
        setRoot(newRoot);
    }

    public IntBSTTest<Integer> maxSumSubtree(int n) {
        IntBSTTest<Integer> maxSubtree = new IntBSTTest<>(super.getComparator());

        if (this.getRoot() == null || n < 1) {
            throw new IllegalStateException("Root is null");
        }
        if(n < 1){
            throw new IllegalStateException("Invalid n");
        }

        //sprawdzam kazde poddrzewo po kolei zaczynajac od najwiekszego

        //lewa strona drzewa
        Node<Integer> current = getRoot();

        while(current != null) {

            int sumResult = sumSubtree(current);

            if (sumResult > max && sumResult <= n) {
                maxSubtree = new IntBSTTest<>(super.getComparator(), current);
            }
            current = (current.getLeft() == null)? current.getRight() : current.getLeft();
        }

        current = getRoot();

        //prawa strona drzewa
        while(current != null) {

            int sumResult = sumSubtree(current);

            if (sumResult > max && sumResult <= n) {
                maxSubtree = new IntBSTTest<>(super.getComparator(), current);
            }
            current = (current.getRight() == null)? current.getLeft() : current.getRight();
        }

        return maxSubtree;
    }


    private int sumSubtree(Node<Integer> node){
        int sum = 0;
        sumSubtreeRecursive(sum, node);
        return sum;
    }

    private void sumSubtreeRecursive(int sum, Node<Integer> node){
        if (node == null){
            return;
        }
        sum += (int) node.getKey();

        if (node.getLeft() != null) {
            sumSubtreeRecursive(sum, node.getLeft());
        }
        if (node.getRight() != null) {
            sumSubtreeRecursive(sum, node.getRight());
        }


    }




}
